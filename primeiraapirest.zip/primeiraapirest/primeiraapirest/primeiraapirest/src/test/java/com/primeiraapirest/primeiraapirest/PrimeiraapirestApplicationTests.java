package com.primeiraapirest.primeiraapirest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiraapirestApplicationTests {

	@Test
	void contextLoads() {
	}

}
