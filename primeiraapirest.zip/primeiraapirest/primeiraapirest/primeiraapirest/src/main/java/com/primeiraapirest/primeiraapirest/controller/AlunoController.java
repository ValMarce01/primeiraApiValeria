package com.primeiraapirest.primeiraapirest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.primeiraapirest.primeiraapirest.model.AlunoModel;
import com.primeiraapirest.primeiraapirest.service.AlunoService;
import com.primeiraapirest.primeiraapirest.repository.AlunoRepository;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/aluno") 
public class AlunoController {

    @Autowired
    private AlunoService alunoService;

    @Autowired
    private AlunoRepository alunoRepository;

    @GetMapping
    public String principal() {
        return "em aluno";
    }

    @GetMapping("/todos")
    public List<AlunoModel> listarTodos() {
        return alunoRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<AlunoModel> buscarPorId(@PathVariable Long id) {
        Optional<AlunoModel> alunoModel = alunoService.buscarPorId(id);
        return alunoModel.map(ResponseEntity::ok)
                         .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @PostMapping
    public ResponseEntity<String> salvar(@Valid @RequestBody AlunoModel aluno) {
        try {
            alunoService.salvar(aluno);
            return ResponseEntity.ok("Salvo com Sucesso!!");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<AlunoModel> atualizar(@PathVariable Long id, @Valid @RequestBody AlunoModel dados) {
        return alunoRepository.findById(id).map(aluno -> {
            aluno.setNomeCompleto(dados.getNomeCompleto());
            aluno.setAnosDeIdade(dados.getAnosDeIdade());
            aluno.setRA(dados.getRA());
            aluno.setNomeCurso(dados.getNomeCurso());
            return ResponseEntity.ok(alunoRepository.save(aluno));
        }).orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (alunoRepository.existsById(id)) {
            alunoRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/buscar")
public List<AlunoModel> buscarPorParametros(
        @RequestParam(required = false) String nome,
        @RequestParam(required = false) String curso,
        @RequestParam(required = false) Integer idade) {

    if (nome  != null) return alunoRepository.findByNomeCompletoContainingIgnoreCase(nome);
    if (curso != null) return alunoRepository.findByNomeCursoContainingIgnoreCase(curso);
    if (idade != null) return alunoRepository.findByAnosDeIdade(idade);

    return alunoRepository.findAll();
}
}
