package com.primeiraapirest.primeiraapirest.model;

import jakarta.persistence.Entity;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name ="aluno")
@PrimaryKeyJoinColumn(name = "idPessoa")
public class AlunoModel extends PessoaModel{
    @NotNull
    private int RA;

    public int getRA() {
        return RA;
    }

    public void setRA(int rA) {
        RA = rA;
    }
    
}
