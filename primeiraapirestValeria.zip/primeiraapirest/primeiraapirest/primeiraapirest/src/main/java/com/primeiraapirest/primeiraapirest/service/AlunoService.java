package com.primeiraapirest.primeiraapirest.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.primeiraapirest.primeiraapirest.model.AlunoModel;
import com.primeiraapirest.primeiraapirest.repository.AlunoRepository;

@Service
public class AlunoService{
    @Autowired
    private AlunoRepository alunoRepository;

    public String salvar(AlunoModel aluno){
        try {
            alunoRepository.saveAndFlush(aluno);    
            return "salvo com sucesso";
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    public Optional<AlunoModel> buscarPorId(Long id){
        return alunoRepository.findById(id);
    }
}
