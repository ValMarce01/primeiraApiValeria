package com.primeiraapirest.primeiraapirest.model;

import jakarta.persistence.*;

@Entity
@Table(name = "pessoa")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class PessoaModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPessoa;

     private String nomeCompleto;
    private int anosDeIdade;
    private String nomeCurso;

    public String getNomeCompleto() { return nomeCompleto; }
    public void setNomeCompleto(String nomeCompleto) { this.nomeCompleto = nomeCompleto; }

    public int getAnosDeIdade() { return anosDeIdade; }
    public void setAnosDeIdade(int anosDeIdade) { this.anosDeIdade = anosDeIdade; }

    public String getNomeCurso() { return nomeCurso; }
    public void setNomeCurso(String nomeCurso) { this.nomeCurso = nomeCurso; }
}