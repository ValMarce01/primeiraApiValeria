package carregabanco;

import carregabanco.view.CarregaBancoView;

public class CarregaBanco {
	public static void main(String[] args) {
		new CarregaBancoView();
	}	
}
